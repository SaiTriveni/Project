package com.capgemini.librarymanagementsystemspringrest.service;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface of User related operations, this gets called after factory object is created.
 *
 */
@SuppressWarnings("unused")
public interface UsersService {
	boolean register(UsersDto user);
	UsersDto login(String email,String password);	
	List<BookDto> searchBookById(int bookId);
	List<BookDto> searchBookByTitle(String bookName);
	List<BookDto> searchBookByAuthor(String bookAuthor);
	List<BookDto> getBooksInfo();
	boolean updatePassword(int id,String currentPassword,String newPassword,String role);

}
