package com.capgemini.librarymanagementsystemspringrest.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

/**
 * 
 * @author Sai Triveni
 * This class implement Serializable interface and has all the booksborrowed related information.
 * @SequenceGenerator creates a sequence of digits for bookId instead of giving in run-time
 *
 */
@SuppressWarnings("serial")
@Data
@Entity
@Table(name="borrowed_books")
@SequenceGenerator(name="seq2", initialValue=1, allocationSize=100)
public class BooksBorrowedDto implements Serializable{
	@Id
	@Column
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "seq2")
	private int id;
	@Column
	private int uId;
	@Column
	private int bId;
	@Column
	private String bookName;

}
