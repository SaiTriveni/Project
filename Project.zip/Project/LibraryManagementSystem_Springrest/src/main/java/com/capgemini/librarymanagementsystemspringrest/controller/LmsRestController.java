package com.capgemini.librarymanagementsystemspringrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;
import com.capgemini.librarymanagementsystemspringrest.dto.LmsResponse;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;
import com.capgemini.librarymanagementsystemspringrest.service.AdminService;
import com.capgemini.librarymanagementsystemspringrest.service.StudentService;
import com.capgemini.librarymanagementsystemspringrest.service.UsersService;

/**
 * 
 * @author Sai Triveni
 * This class controls all the operations of the library.
 * It is linked to UserService, AdminService, StudentService.
 * @RestController annotation is used to create RESTful web services using Spring MVC.
 * @CrossOrigin annotation enables cross-origin resource sharing only for this specific method.
 *
 */
@RestController
@CrossOrigin("http://localhost:4200")
public class LmsRestController {

	@Autowired 
	private UsersService service;
	
	@Autowired
	private AdminService service1;
	
	@Autowired
	private StudentService service2;

	/**
	 * This is a non-static method, helps in registering admin and user based on their choice.
	 * @param user
	 */
	@PostMapping(path = "/addUser", 
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse addUser(@RequestBody UsersDto user) {
		boolean isAdded = service.register(user);

		LmsResponse response = new LmsResponse();
		if(isAdded) {
			response.setMessage("Registration Successfull");
		} else {
			response.setError(true);
			response.setMessage("Registration failed!");
		}
		return response;
	}
	
	/**
	 * This is a non-static method and takes care of login purpose.
	 * @param email,password
	 * @return LmsResponse
	 */
	@PostMapping(path = "/login", 
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse authentication(@RequestBody UsersDto users) {
		UsersDto userLogin = service.login(users.getEmail(), users.getPassword());
		LmsResponse response = new LmsResponse();
		if (userLogin != null) {
			response.setMessage("Login Successfull");
			response.setUserInfo(userLogin);
		} else {
			response.setError(true);
			response.setMessage("Enter valid details!");
		}
		return response;
	}

	/**
	 * This method takes care of adding book into the library, bookDto object has been passed into here.
	 * @param bookDto
	 * @return LmsResponse
	 */
	@PostMapping(path = "/addBook", 
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse addBook(@RequestBody BookDto bean) {
		boolean isAdded = service1.addBook(bean);

		LmsResponse response = new LmsResponse();
		if(isAdded) {
			response.setMessage("Book has been successfully added to library");
		} else {
			response.setError(true);
			response.setMessage("Book is not added to library");
		}
		return response;	
	}

	/**
	 * This method takes care of removing book from the library based on BookId.
	 * @param bookId
	 * @return LmsResponse
	 */
	@DeleteMapping(path="/deleteBook/{bId}",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse removeBook(@PathVariable(name="bId") int bId ) {
		boolean isDeleted = service1.removeBook(bId);
		LmsResponse response = new LmsResponse();
		if(isDeleted) {
			response.setMessage("Book has been deleted successfully from the library");
		} else {
			response.setError(true);
			response.setMessage("Entered book is not deleted from library, try again!");
		}
		return response;		
	}
	
	/**
	 * This method updates the book based on our requirements.
	 * @param bookDto
	 * @return LmsResponse
	 */
	@PutMapping(path = "/updateBook",
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse updateBook(@RequestBody BookDto bean) {
		boolean isUpdated = service1.updateBook(bean);
		LmsResponse response = new LmsResponse();
		if(isUpdated) {
			response.setMessage("Book details have been updated successfully");
		} else {
			response.setError(true);
			response.setMessage("Book has not been updated!");
		}
		return response;		
	}
	
	/**
	 * This method returns the Id of every book in the library.
	 * @param bookId
	 * @return LmsResponse
	 */
	@GetMapping(path="/getBooksById",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse getBooksById( int bId) {
		List<BookDto> recordList = service.searchBookById(bId);
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setBooksInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("Entered BookId is not present in the library");
		}
		return response;
				
	}
	
	/**
	 * This method returns all the books that are having title same as we pass during run-time.
	 * @param bookName
	 * @return LmsResponse
	 */
	@GetMapping(path="/getBooksByTitle/{bookName}",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse getBooksByTitle(@PathVariable(name="bookName") String bookName) {
		List<BookDto> recordList = service.searchBookByTitle(bookName);
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setBooksInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("Books with bookTitle as "+bookName+" are not present in the library");
		}
		return response;
				
	}
	
	/**
	 * This method returns all the books that are having author name same as we pass during run-time.
	 * @param bookAuthor
	 * @return LmsResponse
	 */
	@GetMapping(path="/getBooksByAuthor/{author}",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse getBooksByAuthor(@PathVariable(name="author") String author) {
		List<BookDto> recordList = service.searchBookByAuthor(author);
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setBooksInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("Books with "+author+" bookAuthor are not present in the library");
		}
		return response;
				
	}
	
	/**
	 * This method returns all the information of books present in the library.
	 * @return LmsResponse
	 */
	@GetMapping(path="/getBooksInfo",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse getBooksInfo() {
		List<BookDto> recordList = service.getBooksInfo();
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setBooksInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("Books are not available in the library");
		}
		return response;
	}
	
	/**
	 * This method returns the details of all the borrowed books.
	 * @param booksBorrowedDto
	 * @return LmsResponse
	 */
	@PostMapping(path="/getBorrowedBooks",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse getBorrowedBooks(@RequestBody BooksBorrowedDto bean) {
		List<BooksBorrowedDto> recordList = service2.borrowedBook(bean.getUId());
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setBorrowedBooks(recordList);
		} else {
			response.setError(true);
			response.setMessage("This user have not borrowed any books from the library");
		}
		return response;
	}
	
	/**
	 * This method shows all the requests placed to have a book from the library.
	 * @return LmsResponse
	 */ 
	@GetMapping(path="/showRequests",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse showRequests() {
		List<RequestDto> recordList = service1.showRequests();
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setRequests(recordList);
		} else {
			response.setError(true);
			response.setMessage("Requests for books was not placed");
		}
		return response;
	}
	
	/**
	 * This method returns information all the books that are issued from the library.
	 * @return LmsResponse
	 */
	@GetMapping(path="/showIssuedBooks",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse showIssuedBooks() {
		List<BookIssueDetailsDto> recordList = service1.showIssuedBooks();
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setIssueInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("Books was not issued to any user");
		}
		return response;
	}
	
	/**
	 * This method shows the list of users/students present in the library.
	 * @return LmsResponse
	 */
	@GetMapping(path="/showUsers",
			produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse showUsers() {
		List<UsersDto> recordList = service1.showUsers();
		LmsResponse response = new LmsResponse();
		
		if(recordList != null && !recordList.isEmpty()) {
			response.setUsersInfo(recordList);
		} else {
			response.setError(true);
			response.setMessage("There are no users in the library");
		}
		return response;
	}
	
	/**
	 * This method is used to update the password of either student or admin.
	 * @param id
	 * @param password
	 * @param newPassword
	 * @param role
	 * @return LmsResponse
	 */
	@PutMapping(path = "/updatePassword",
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse updatePassord(int id, String password, String newPassword, String role) {
		boolean isUpdated = service.updatePassword(id, password, newPassword, role);
		LmsResponse response = new LmsResponse();
		
		if(isUpdated) {
			response.setMessage("Password has been changed Successfully");
		} else {
			response.setError(true);
			response.setMessage("Password cannot be updated!");
		}
		return response;	
	}
	
	/**
	 * This method is used to request a book from the library.
	 * @param requestDto
	 * @return LmsResponse
	 */
	@PostMapping(path = "/requestBook", 
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse requestBook(@RequestBody RequestDto bean) {
		boolean isRequested = service2.requestBook(bean.getUId(), bean.getBId());

		LmsResponse response = new LmsResponse();
		if(isRequested) {
			response.setMessage("Request has been placed successfully to borrow a book");
		} else {
			response.setError(true);
			response.setMessage("Request has not been placed to borrow a book!");
		}
		return response;
	}

	/**
	 * This method is used to issue a book to the user.
	 * @param bookIssueDetailsDto
	 * @return LmsResponse
	 */
	@PostMapping(path = "/issueBook", 
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse issueBook(@RequestBody BookIssueDetailsDto bean) {
		boolean isIssued = service1.issueBook(bean.getBId(),bean.getUId());

		LmsResponse response = new LmsResponse();
		if(isIssued) {
			response.setMessage("Book has been issued to the user successfully");
		} else {
			response.setError(true);
			response.setMessage("Book was not issued to the user successfully");
		}
		return response;
	}
	
	/**
	 * This method is used to return the book to the library. Book information is passed as object to return it.
	 * @param BookIssueDetailsDto
	 * @return LmsResponse
	 */
	@PostMapping(path="/returnBook",
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public LmsResponse returnBook(@RequestBody BookIssueDetailsDto bean) {
		boolean isReturned = service2.returnBook(bean.getBId(), bean.getUId());
		LmsResponse response = new LmsResponse();
		if(isReturned) {
			response.setMessage("Book has been returned to the library Successfully");
		} else {
			response.setError(true);
		}
		return response;		
	}
	
	/**
	 * This method is used to cancel the request placed by the user to get a book.
	 * @param requestDto
	 * @return LmsResponse
	 */
	@PostMapping(path="/cancelRequest",
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	public  LmsResponse cancelRequest(@RequestBody RequestDto bean) {
		boolean isCancelled = service1.cancelRequest(bean.getUId(), bean.getBId());
		LmsResponse response = new LmsResponse();
		if(isCancelled) {
			response.setMessage("Request has been cancel by librarian to borrow a book");
		}else {
			response.setError(true);
			response.setMessage("Request has not been cancelled by the librarian");
		}
		return response;
	}
		
}
