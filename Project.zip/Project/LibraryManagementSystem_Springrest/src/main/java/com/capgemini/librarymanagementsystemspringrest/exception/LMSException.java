package com.capgemini.librarymanagementsystemspringrest.exception;

/**
 * 
 * @author Sai Triveni
 * This is a class of Exception which extends RuntimeException class and it has a constructor with arguments in it.
 *
 */
@SuppressWarnings("serial")
public class LMSException extends RuntimeException{
	public LMSException(String message) {
		super(message);
	}
}
