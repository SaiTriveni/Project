package com.capgemini.librarymanagementsystemspringrest.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of Admin only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 *
 */
public interface AdminDao {
	boolean addBook(BookDto book);
	boolean removeBook(int bookId);
	boolean updateBook(BookDto book);
	List<RequestDto> showRequests();
	List<BookIssueDetailsDto> showIssuedBooks();
	List<UsersDto> showUsers();
	boolean issueBook(int bookId,int userId);
	List<Integer> bookIssuedDetails(int userId);
	boolean cancelRequest(int userId,int bookId);
}
