package com.capgemini.librarymanagementsystemspringrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.librarymanagementsystemspringrest.dao.UsersDao;
import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

/**
 * 
 * @author Sai Triveni
 * This is the implementation of userService interface and handles all the unimplemented methods.
 *
 */
@Service
public class UsersServiceImplementation implements UsersService{

	@Autowired
	private UsersDao dao;

	@Override
	public boolean register(UsersDto user) {
		return dao.register(user);
	}

	@Override
	public UsersDto login(String email, String password) {
		return dao.login(email, password);
	}

	@Override
	public List<BookDto> searchBookById(int bookId) {
		return dao.searchBookById(bookId);
	}

	@Override
	public List<BookDto> searchBookByTitle(String bookName) {
		return dao.searchBookByTitle(bookName);
	}

	@Override
	public List<BookDto> searchBookByAuthor(String bookAuthor) {
		return dao.searchBookByAuthor(bookAuthor);
	}

	@Override
	public List<BookDto> getBooksInfo() {
		return dao.getBooksInfo();
	}

	@Override
	public boolean updatePassword(int id, String currentPassword, String newPassword, String role) {
		return dao.updatePassword(id, currentPassword, newPassword, role);
	}

	
}
