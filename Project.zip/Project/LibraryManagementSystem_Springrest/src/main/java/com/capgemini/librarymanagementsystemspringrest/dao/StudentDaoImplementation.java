package com.capgemini.librarymanagementsystemspringrest.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.exception.LMSException;

/**
 * 
 * @author Sai Triveni This class implements StudentDao.
 *
 */
@Repository
public class StudentDaoImplementation implements StudentDao {

	EntityManager manager = null;
	EntityTransaction transaction = null;
	int noOfBooks;

	@PersistenceUnit
	private EntityManagerFactory factory;

	/**
	 * This method lists out all the books borrowed from the library.
	 * 
	 * @param userId
	 * @return List<BooksBorrowedDto>
	 */
	@Override
	public List<BooksBorrowedDto> borrowedBook(int userId) {
		try {
			manager = factory.createEntityManager();
			String jpql = "select b from BooksBorrowedDto b where b.uId=:uId";
			TypedQuery<BooksBorrowedDto> query = manager.createQuery(jpql, BooksBorrowedDto.class);
			query.setParameter("uId", userId);
			List<BooksBorrowedDto> recordList = query.getResultList();
			return recordList;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	/**
	 * This method is used to place a request to get a book
	 * 
	 * @param userId
	 * @param bookId
	 * @return boolean
	 */
	@SuppressWarnings({ "rawtypes", "unused" })
	@Override
	public boolean requestBook(int userId, int bookId) {
		int count = 0;
		try {
			manager = factory.createEntityManager();
			String p = "select b from BooksBorrowedDto b where b.uId=:uId and b.bId=:bId ";
			TypedQuery<BooksBorrowedDto> tq = manager.createQuery(p, BooksBorrowedDto.class);
			tq.setParameter("uId", userId);
			tq.setParameter("bId", bookId);
			List<BooksBorrowedDto> bb = tq.getResultList();
			if (bb.isEmpty()) {
				String q = "select r from RequestDto r where r.uId=:uId and r.bId=:bId";
				TypedQuery<RequestDto> requestQuery = manager.createQuery(q, RequestDto.class);
				requestQuery.setParameter("uId", userId);
				requestQuery.setParameter("bId", bookId);
				List<RequestDto> record = requestQuery.getResultList();
				if (record.isEmpty()) {
					transaction = manager.getTransaction();
					String jpql = "select b from BookDto b where b.bId=:bId";
					TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
					query.setParameter("bId", bookId);
					List rs = query.getResultList();
					if (rs != null) {
						String jpql1 = "select b from BooksBorrowedDto b where b.uId=:uId and b.bId=:bId";
						TypedQuery<BooksBorrowedDto> query1 = (TypedQuery<BooksBorrowedDto>) manager.createQuery(jpql1,
								BooksBorrowedDto.class);
						query1.setParameter("uId", userId);
						query1.setParameter("bId", bookId);
						List rs1 = query1.getResultList();
						if (rs1.isEmpty() || rs1 == null) {
							String jpql2 = "select b from BookIssueDetailsDto b where b.uId=:uId";
							TypedQuery<BookIssueDetailsDto> query2 = (TypedQuery<BookIssueDetailsDto>) manager
									.createQuery(jpql2, BookIssueDetailsDto.class);
							query2.setParameter("uId", userId);
							List<BookIssueDetailsDto> rs2 = query2.getResultList();
							for (BookIssueDetailsDto i : rs2) {
								noOfBooks = count++;
							}
							if (noOfBooks < 3) {
								Query bookName = manager
										.createQuery("select b.bookName from BookDto b where b.bId=:bookId");
								bookName.setParameter("bookId", bookId);
								List book = bookName.getResultList();
								Query email = manager
										.createQuery("select u.email from UsersDto u where u.uId=:user_Id");
								email.setParameter("user_Id", userId);
								List userEmail = email.getResultList();
								transaction.begin();
								RequestDto request = new RequestDto();
								request.setUId(userId);
								request.setBId(bookId);
								request.setEmail(userEmail.get(0).toString());
								request.setBookName(book.get(0).toString());
								manager.persist(request);
								transaction.commit();
								return true;

							} else {
								throw new LMSException("You exceeded the number of books allowed to taken by user!");
							}
						} else {
							throw new LMSException("The requested book cannot be borrowed,as it already taken");
						}
					} else {
						throw new LMSException("Book with entered bookId is not present");
					}

				} else {
					throw new LMSException("Book has already been requested Successfully");
				}

			} else {
				throw new LMSException("User had already borrowed the book");
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	/**
	 * This method is used to return book to the library
	 * 
	 * @param bookId
	 * @param userId
	 * @return boolean
	 */
	@Override
	public boolean returnBook(int bookId, int userId) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			String jpql = "select b from BookDto b where b.bId=:bId";
			TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
			query.setParameter("bId", bookId);
			BookDto rs = query.getSingleResult();
			if (rs != null) {
				String jpql1 = "select b from BookIssueDetailsDto b where b.bId=:bId and b.uId=:uId ";
				TypedQuery<BookIssueDetailsDto> query1 = manager.createQuery(jpql1, BookIssueDetailsDto.class);
				query1.setParameter("bId", bookId);
				query1.setParameter("uId", userId);
				BookIssueDetailsDto rs1 = query1.getSingleResult();
				if (rs1 != null) {
					Date issueDate = rs1.getIssueDate();
					Calendar cal = Calendar.getInstance();
					Date returnDate = cal.getTime();
					long difference = issueDate.getTime() - returnDate.getTime();
					float daysBetween = (difference / (1000 * 60 * 60 * 24));
					if (daysBetween > 7.0) {

						throw new LMSException("Fine has been imposed on user for delaying in return");
					} else {
						transaction.begin();
						manager.remove(rs1);
						transaction.commit();

						transaction.begin();
						String jpql3 = "select b from BooksBorrowedDto b  where b.bId=:bId and b.uId=:uId";
						Query query3 = manager.createQuery(jpql3);
						query3.setParameter("bId", bookId);
						query3.setParameter("uId", userId);
						BooksBorrowedDto bbb = (BooksBorrowedDto) query3.getSingleResult();
						manager.remove(bbb);
						transaction.commit();

						return true;

					}
				} else {
					transaction.begin();
					manager.remove(rs1);
					transaction.commit();

					transaction.begin();
					String jpql3 = "select b from BooksBorrowedDto b  where b.bId=:bId and b.uId=:uId";
					Query query3 = manager.createQuery(jpql3);
					query3.setParameter("bId", bookId);
					query3.setParameter("uId", userId);
					BooksBorrowedDto bbb = (BooksBorrowedDto) query3.getSingleResult();
					manager.remove(bbb);
					transaction.commit();

					return true;
				}

			} else {
				throw new LMSException("Book is not present in the library!");
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

}
