package com.capgemini.librarymanagementsystemspringrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.librarymanagementsystemspringrest.dao.StudentDao;
import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;
/**
 * 
 * @author Sai Triveni
 * This is the implementation of Student Service interface and handles all the unimplemented methods.
 *
 */
@Service
public class StudentServiceImplementation implements StudentService{
	
	@Autowired
	private StudentDao dao;

	@Override
	public List<BooksBorrowedDto> borrowedBook(int userId) {
		return dao.borrowedBook(userId);
	}

	@Override
	public boolean requestBook(int userId, int bookId) {
		return dao.requestBook(userId, bookId);
	}

	@Override
	public boolean returnBook(int bookId, int userId) {
		return dao.returnBook(bookId, userId);
	}


}
