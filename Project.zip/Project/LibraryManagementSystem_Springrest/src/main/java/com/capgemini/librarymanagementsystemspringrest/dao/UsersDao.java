package com.capgemini.librarymanagementsystemspringrest.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of User only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 */
public interface UsersDao {
	boolean register(UsersDto user);
	UsersDto login(String email,String password);	
	List<BookDto> searchBookById(int bookId);
	List<BookDto> searchBookByTitle(String bookName);
	List<BookDto> searchBookByAuthor(String bookauthor);
	List<BookDto> getBooksInfo();
	boolean updatePassword(int id,String currentPassword,String newPassword,String role);

}
