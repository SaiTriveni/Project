package com.capgemini.librarymanagementsystemspringrest;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.librarymanagementsystemspringrest.dao.UsersDao;
import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

public class UserDAOTest {
	@Autowired
	private UsersDao dao;
	
	@Test
	public void testRegisterValid() {
		UsersDto userDto = new UsersDto();
		userDto.setUserName("Akhil");
		userDto.setEmail("akhil@gmail.com");
		userDto.setPassword("Akhil@999");
		userDto.setRole("student");
		boolean check = dao.register(userDto);
		Assertions.assertTrue(check);		
	}	
	@Test
	public void testRegisterInvalid() {
		UsersDto userDto = new UsersDto();
		userDto.setUserName("Akhil");
		userDto.setEmail("akhil@gmail.com");
		userDto.setPassword("Akhil@999");
		userDto.setRole("student");
		boolean check = dao.register(userDto);
		Assertions.assertFalse(check);
	}

	@Test
	public void testLoginValid() {
		UsersDto info = dao.login("sai@gmail.com", "Sai@160498");
		Assertions.assertNotNull(info);
	}
	
	@Test
	public void testLoginInvalid() {
		UsersDto info = dao.login("sai@gmail.com", "sai160498");
		Assertions.assertNull(info);
	}
	
	@Test
	public void testSearchBookByIdValid() {
		List<BookDto> info = dao.searchBookById(101);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());
		
	}
	
	@Test
	public void testSearchBookByIdInvalid() {
		List<BookDto> info = dao.searchBookById(109);
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}
	
	@Test
	public void testSearchBookByTitleValid() {
		List<BookDto> info = dao.searchBookByTitle("Java");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}
	
	@Test
	public void testSearchBookByTitleInvalid() {
		List<BookDto> info = dao.searchBookByTitle("Jaava");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());		
	}
	
	@Test
	public void testSearchBookByAuthorValid() {
		List<BookDto> info = dao.searchBookByAuthor("Sunil");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(1, info.size());		
	}
	
	@Test
	public void testSearchBookByAuthorInvalid() {
		List<BookDto> info = dao.searchBookByAuthor("Yash");
		Assertions.assertNotNull(info);
		Assertions.assertEquals(0, info.size());	
	}
	
	@Test
	public void testBooksInfoValid() {
		List<BookDto> info = dao.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertEquals(5, info.size());
	}
	
	@Test
	public void testBooksInfoInvalid() {
		List<BookDto> info = dao.getBooksInfo();
		Assertions.assertNotNull(info);
		Assertions.assertNotEquals(6, info.size());
	}
	
	@Test
	public void testUpdatePasswordValid() {
		boolean check = dao.updatePassword(100102, "Sai@160498", "Sai@123", "admin");
		Assertions.assertTrue(check);
	}
	
	@Test
	public void testUpdatePasswordInvalid() {
		boolean check = dao.updatePassword(100102, "Sai@160498", "Sai@123", "student");
		Assertions.assertFalse(check);
	}
	
}
