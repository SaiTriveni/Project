import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router : Router) { }

  ngOnInit() {
  }
  isAdmin() {
    const adminDetails = JSON.parse(localStorage.getItem('userInfo'));
    if (adminDetails && adminDetails.userInfo.role === 'admin') {
      return true;
    } else {
      return false;
    }
  }

  isStudent() {
    const studentDetails = JSON.parse(localStorage.getItem('userInfo'));
    if (studentDetails && studentDetails.userInfo.role === 'student') {
      return true;
    } else {
      return false;
    }
  }

  logout() {
    localStorage.removeItem('userInfo');
    this.router.navigateByUrl('/login');
  }

}
