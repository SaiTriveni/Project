import { PipeTransform, Pipe } from '@angular/core';


interface Book {
    bid: number;
    bookName: string;
    author: string;
    category: string;
    publisher: string;
}

@Pipe({
    name: 'filter'
})
export class BookFilterPipe implements PipeTransform {
    transform(booksInfo: Book[], search: string): Book[] {
        if (search === undefined) {
            return booksInfo;
        } else {
            return booksInfo.filter(book => {
                return book.bookName.toLowerCase().includes(search.toLowerCase()) ||
                    book.author.toLowerCase().includes(search.toLowerCase()) ||
                    book.category.toLowerCase().includes(search.toLowerCase());
            });

        }
    }
}
